##Input types:##

* email
* textbox
* checkbox
* password
* <select> tag to allow users to select from options  